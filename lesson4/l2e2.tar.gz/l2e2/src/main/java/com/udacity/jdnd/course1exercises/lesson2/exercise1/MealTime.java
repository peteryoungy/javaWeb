package com.udacity.jdnd.course1exercises.lesson2.exercise1;

public enum MealTime {
    BREAKFAST, LUNCH, DINNER;
}
