package com.udacity.jdnd.course1.data;

public class Order {
    private Integer id;
    private Integer customerId;

    /* getters and setters not shown */

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getCustomerId() {
        return customerId;
    }

    public void setCustomerId(Integer customerId) {
        this.customerId = customerId;
    }
}
